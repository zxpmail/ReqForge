﻿# Hook: UserPromptSubmit
# Detect correction/feedback signals in user prompt via PowerShell
$c = $input | Out-String
if ($c) {
    try {
        $p = ($c | ConvertFrom-Json).prompt
        if ($p -match '不是这样|你搞错|你错了|不对|不应该|你漏了|你忘了|改一下|不合理|你理解错|我说的不是|为什么没|没有执行|没有生效|又忘了|怎么还|再说一遍|你到底|能不能|不要再|别再|停下|不用管|先不要') {
            Write-Host '{"additionalContext": "Detected user correction signal. Dispatch feedback-observer after handling."}'
        }
    } catch {}
}
